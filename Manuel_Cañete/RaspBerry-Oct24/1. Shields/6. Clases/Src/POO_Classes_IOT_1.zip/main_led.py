import led_classe

 led1 = LED(23)
 
 while True:
     time.sleep(1)
     led1.toggle()